package id.go.dephub.itjen.portal.rb.model

import java.io.Serializable

data class RbModel(val title: String, val url: String) : Serializable