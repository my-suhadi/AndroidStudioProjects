package id.go.dephub.itjen.portal.buletin.model

import java.io.Serializable

data class Buletin(val nomorBuletin: String, val buletinUrl: String) : Serializable