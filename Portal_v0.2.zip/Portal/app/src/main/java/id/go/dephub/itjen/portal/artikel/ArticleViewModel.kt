package id.go.dephub.itjen.portal.artikel

import androidx.lifecycle.ViewModel

class ArticleViewModel : ViewModel() {
}
