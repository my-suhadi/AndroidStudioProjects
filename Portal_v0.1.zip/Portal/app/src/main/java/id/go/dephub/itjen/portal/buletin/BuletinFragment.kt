package id.go.dephub.itjen.portal.buletin

import androidx.lifecycle.ViewModelProviders
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup

import id.go.dephub.itjen.portal.R

class BuletinFragment : Fragment() {

    companion object {
        fun newInstance() = BuletinFragment()
    }

    private lateinit var viewModel: BuletinViewModel

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.buletin_fragment, container, false)
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        viewModel = ViewModelProviders.of(this).get(BuletinViewModel::class.java)
    }

}
