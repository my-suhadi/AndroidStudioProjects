package id.go.dephub.itjen.portal.beranda.model


import com.google.gson.annotations.SerializedName

data class Title(
    @SerializedName("rendered")
    val rendered: String
)