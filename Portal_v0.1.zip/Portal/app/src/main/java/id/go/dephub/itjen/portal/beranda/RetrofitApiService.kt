package id.go.dephub.itjen.portal.beranda

import id.go.dephub.itjen.portal.beranda.model.media.Image
import id.go.dephub.itjen.portal.beranda.model.Post
import okhttp3.OkHttpClient
import retrofit2.Call
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query

interface RetrofitApiService {
    @GET("wp/v2/posts")
    fun getAllPosts(): Call<List<Post>>
    @GET("wp/v2/media/{id}")
    fun getImage(@Path("id") id : Int ): Call<Image>

    companion object {
        fun create(httpClient: OkHttpClient) : RetrofitApiService {
            val retrofit = Retrofit.Builder()
                .baseUrl("https://itjen.dephub.go.id/wp-json/")
                .addConverterFactory(GsonConverterFactory.create())
                .client(httpClient)
                .build()
            return retrofit.create(RetrofitApiService::class.java)
        }
    }
}