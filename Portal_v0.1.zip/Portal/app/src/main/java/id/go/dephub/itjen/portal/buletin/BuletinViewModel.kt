package id.go.dephub.itjen.portal.buletin

import androidx.lifecycle.ViewModel

class BuletinViewModel : ViewModel() {
}
