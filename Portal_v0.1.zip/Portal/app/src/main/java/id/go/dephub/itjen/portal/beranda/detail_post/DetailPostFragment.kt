package id.go.dephub.itjen.portal.beranda.detail_post

import android.os.Bundle
import android.util.Log.d
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.webkit.SslErrorHandler
import android.webkit.WebView
import android.webkit.WebViewClient
import id.go.dephub.itjen.portal.Connection
import id.go.dephub.itjen.portal.R
import kotlinx.android.synthetic.main.fragment_detail_post.*
import okhttp3.Call
import okhttp3.Request
import okhttp3.Response
import java.io.IOException

class DetailPostFragment : Fragment() {

    lateinit var postLink: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        postLink = arguments!!.getString("postLink")!!
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_detail_post, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val okClient= Connection().makeConnection(context!!)

        val okRequest = Request.Builder()
            .url(postLink)
            .build()

        okClient.newCall(okRequest).enqueue(object : okhttp3.Callback{
            override fun onFailure(call: Call, e: IOException) {
                d("DetailPostFragment", "onFailuer: ${e.localizedMessage}")
            }

            override fun onResponse(call: Call, response: Response) {
                activity?.runOnUiThread(Runnable {
                    val webView = view.findViewById<WebView>(R.id.webDetailPost)
                    webView.webViewClient = object : WebViewClient() {
                        override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean {
                            view?.loadUrl(url)
                            return true
                        }
                    }
                    webView.loadUrl(postLink)
                    // webView.loadUrl("https://google.com")
                })
            }
        })
    }
}
